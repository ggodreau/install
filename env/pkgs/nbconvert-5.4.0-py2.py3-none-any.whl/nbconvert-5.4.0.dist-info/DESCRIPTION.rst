

Nbconvert is a Command Line tool and Python library and API to process and
convert Jupyter notebook into a variety of other formats.

Using nbconvert enables:

  - presentation of information in familiar formats, such as PDF.
  - publishing of research using LaTeX and opens the door for embedding notebooks in papers.
  - collaboration with others who may not use the notebook in their work.
  - sharing contents with many people via the web using HTML.


