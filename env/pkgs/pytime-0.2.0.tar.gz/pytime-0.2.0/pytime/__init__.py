__title__ = 'pytime'
__license__ = 'MIT'
__author__ = 'Sinux (nsinux@gmail.com)'
__version__ = '0.2.0'
